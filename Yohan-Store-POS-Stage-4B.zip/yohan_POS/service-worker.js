/* ===================================================================
   Yohan Store POS - application service worker
   Stage 4B, Phase A: offline APP ACCESS only (no offline sales or data yet).

   A browser allows only ONE service worker per scope, and this app already uses
   firebase-messaging-sw.js for push notifications. If both were registered at the
   same scope they would keep replacing each other. So this single worker does both jobs:

     1. PUSH NOTIFICATIONS - it loads firebase-messaging-sw.js (that file is unchanged).
     2. OFFLINE APP ACCESS - it keeps a copy of the app files and the public Firebase
        library files, so the screen can open without internet after one online visit.

   What is saved on the device:
     - the app's own files (index.html, style.css, app.js, pwa.js, manifest, icons)
     - the public Firebase library code from www.gstatic.com/firebasejs/ (code, not data)

   What is NEVER saved or touched by this worker:
     - sign-in / Authentication traffic, user profiles, Firestore data, sales, costs,
       push tokens, or anything else sent to Google/Firebase API servers.
       Those requests are simply not handled here: the browser sends them as usual.

   To force every device to download fresh copies, raise CACHE_VERSION below.
   =================================================================== */

// Push notifications (unchanged file). If it cannot be loaded right now, offline access
// below still works; alerts come back as soon as the worker updates with a connection.
try {
  importScripts("./firebase-messaging-sw.js");
} catch (error) {
  console.warn("[service-worker] Could not load firebase-messaging-sw.js:", error);
}

(function () {
  "use strict";

  const CACHE_PREFIX = "yohan-pos-";
  const CACHE_VERSION = "v1";
  const SHELL_CACHE = CACHE_PREFIX + "shell-" + CACHE_VERSION;
  const SDK_CACHE = CACHE_PREFIX + "firebase-sdk-v1";
  const CURRENT_CACHES = [SHELL_CACHE, SDK_CACHE];

  // If the network has not answered in this time, use the saved copy instead.
  const NETWORK_TIMEOUT_MS = 4000;

  const REQUIRED_FILES = ["./index.html", "./style.css", "./app.js", "./pwa.js", "./manifest.json"];
  const OPTIONAL_FILES = [
    "./",
    "./icon-192.png",
    "./icon-512.png",
    "./icon-maskable-512.png",
    "./apple-touch-icon.png"
  ];

  const toUrl = (path) => new URL(path, self.location.href).href;
  const ROOT_URL = toUrl("./");
  const INDEX_URL = toUrl("./index.html");
  const APP_FILE_URLS = new Set(REQUIRED_FILES.concat(OPTIONAL_FILES).map(toUrl));

  const withoutSearch = (url) => url.origin + url.pathname;

  // Public Firebase library files only, for example
  // https://www.gstatic.com/firebasejs/13.1.0/firebase-app.js
  function isFirebaseLibraryFile(url) {
    return url.origin === "https://www.gstatic.com" &&
      /^\/firebasejs\/\d+\.\d+\.\d+\/[A-Za-z0-9._-]+\.js$/.test(url.pathname);
  }

  function isAppFile(url) {
    return url.origin === self.location.origin && APP_FILE_URLS.has(withoutSearch(url));
  }

  function isAppPage(request, url) {
    return request.mode === "navigate" &&
      url.origin === self.location.origin &&
      (withoutSearch(url) === ROOT_URL || withoutSearch(url) === INDEX_URL);
  }

  // Only keep good, complete, same-kind answers (never errors, redirects or partial files).
  function isStorable(response) {
    return Boolean(response) &&
      response.status === 200 &&
      response.type !== "opaque" &&
      response.type !== "error" &&
      !response.redirected;
  }

  async function fetchAndStore(cache, path) {
    const url = toUrl(path);
    const response = await fetch(new Request(url, { cache: "reload" }));   // skip the browser's old copy
    if (!response.ok) throw new Error(url + " answered " + response.status);
    await cache.put(url, response);
  }

  // ---------- install: save the app files ----------
  self.addEventListener("install", (event) => {
    event.waitUntil((async () => {
      const cache = await caches.open(SHELL_CACHE);

      // Required files: if one is missing the install fails and the old worker keeps running.
      await Promise.all(REQUIRED_FILES.map((path) => fetchAndStore(cache, path)));

      // Optional files (icons, "/"): never block the install.
      await Promise.all(OPTIONAL_FILES.map((path) => fetchAndStore(cache, path).catch(() => {})));

      await self.skipWaiting();
    })());
  });

  // ---------- activate: remove OLD app caches of ours only ----------
  self.addEventListener("activate", (event) => {
    event.waitUntil((async () => {
      const names = await caches.keys();
      await Promise.all(
        names
          .filter((name) => name.startsWith(CACHE_PREFIX) && !CURRENT_CACHES.includes(name))
          .map((name) => caches.delete(name))
      );
      await self.clients.claim();
    })());
  });

  // ---------- fetch ----------
  self.addEventListener("fetch", (event) => {
    const request = event.request;
    if (request.method !== "GET" || request.headers.has("range")) return;

    const url = new URL(request.url);

    if (isFirebaseLibraryFile(url)) {
      event.respondWith(cacheFirst(event, SDK_CACHE));
    } else if (isAppFile(url) || isAppPage(request, url)) {
      event.respondWith(networkFirst(event));
    }
    // Anything else (Firebase Auth, Firestore, push, fonts, other sites): not handled here.
    // The browser deals with it normally and nothing is stored.
  });

  // Library files never change for a given version number, so the saved copy is always right.
  async function cacheFirst(event, cacheName) {
    const cache = await caches.open(cacheName);
    const saved = await cache.match(event.request);
    if (saved) return saved;

    const response = await fetch(event.request);   // offline + not saved yet: the browser shows its normal error
    if (isStorable(response)) {
      event.waitUntil(cache.put(event.request, response.clone()).catch(() => {}));
    }
    return response;
  }

  // App files: online = always the newest version (and refresh the saved copy).
  // Offline or very slow = the saved copy.
  async function networkFirst(event) {
    const request = event.request;
    const cache = await caches.open(SHELL_CACHE);

    const fromNetwork = fetch(request).then((response) => {
      if (isStorable(response)) {
        cache.put(request, response.clone()).catch(() => {});
      }
      return response;
    });
    event.waitUntil(fromNetwork.catch(() => {}));   // let the saving finish

    try {
      const timer = new Promise((resolve) => setTimeout(() => resolve(null), NETWORK_TIMEOUT_MS));
      const first = await Promise.race([fromNetwork, timer]);
      if (first) return first;

      const saved = await findSaved(request, cache);
      return saved || await fromNetwork;            // nothing saved: keep waiting for the network
    } catch (error) {
      const saved = await findSaved(request, cache);
      if (saved) return saved;
      return new Response("You are offline and this file has not been saved yet. Open the app once while online.", {
        status: 503,
        statusText: "Offline",
        headers: { "Content-Type": "text/plain; charset=utf-8" }
      });
    }
  }

  async function findSaved(request, cache) {
    let saved = await cache.match(request, { ignoreSearch: true });
    if (!saved && request.mode === "navigate") {
      saved = (await cache.match(INDEX_URL)) || (await cache.match(ROOT_URL));
    }
    return saved;
  }

  // ---------- messages from the page ----------
  // On the very first visit the Firebase library files were loaded BEFORE this worker took
  // over, so the page tells us which ones it used and we save them too.
  self.addEventListener("message", (event) => {
    const data = event.data || {};
    if (data.type === "CACHE_URLS" && Array.isArray(data.urls)) {
      event.waitUntil(saveLoadedLibraryFiles(data.urls));
    }
  });

  async function saveLoadedLibraryFiles(urls) {
    const cache = await caches.open(SDK_CACHE);

    for (const item of urls.slice(0, 80)) {
      let url;
      try { url = new URL(String(item)); } catch (error) { continue; }

      if (!isFirebaseLibraryFile(url)) continue;   // safety: public library code only
      if (await cache.match(url.href)) continue;

      try {
        const response = await fetch(url.href, { mode: "cors", credentials: "omit" });
        if (isStorable(response)) await cache.put(url.href, response);
      } catch (error) { /* try again on the next visit */ }
    }
  }
})();
