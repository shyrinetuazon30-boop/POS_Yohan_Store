// Yohan Store POS - PWA helper (Stage 4B, Phase A)
// 1. Shows "Online" / "Offline" and updates when the browser notices a change.
// 2. Registers the application service worker (service-worker.js).
//
// This file is a normal script that does not depend on Firebase, so the indicator keeps
// working even if app.js could not start.
(function () {
  "use strict";

  // ---------------------------------------------------------------
  // Online / Offline indicator
  // ---------------------------------------------------------------
  function updateConnectionStatus() {
    const box = document.getElementById("connectionStatus");
    const label = document.getElementById("connectionLabel");
    if (!box || !label) return;

    const online = navigator.onLine !== false;
    box.dataset.state = online ? "online" : "offline";
    label.textContent = online ? "Online" : "Offline";
    box.title = online
      ? "Connected to the internet."
      : "No internet connection. The app screen can open, but selling and saving need internet for now.";
  }

  window.addEventListener("online", updateConnectionStatus);
  window.addEventListener("offline", updateConnectionStatus);
  updateConnectionStatus();

  // ---------------------------------------------------------------
  // Service worker registration
  // ---------------------------------------------------------------
  // Service workers only run on https:// or on localhost / 127.0.0.1 (Live Server is fine).
  if (!("serviceWorker" in navigator) || !window.isSecureContext) {
    console.info("PWA: offline access is not available here (needs https or localhost).");
    return;
  }

  // IMPORTANT: app.js registers this SAME file for push notifications. Keep the two URLs
  // identical. Registering one file at one scope twice is harmless.
  const WORKER_URL = new URL("service-worker.js", window.location.href).href;

  // Ask the worker to also save the public Firebase library files this page just loaded.
  function saveLibraryFilesForOffline(registration) {
    const urls = performance
      .getEntriesByType("resource")
      .map((entry) => entry.name)
      .filter((name) => name.indexOf("https://www.gstatic.com/firebasejs/") === 0);

    if (registration.active && urls.length) {
      registration.active.postMessage({ type: "CACHE_URLS", urls: urls });
    }
  }

  // First visit, or an upgrade from the old notification-only worker: when the new worker
  // takes control, tell it which library files to keep.
  navigator.serviceWorker.addEventListener("controllerchange", function () {
    navigator.serviceWorker.getRegistration().then(function (registration) {
      if (registration) saveLibraryFilesForOffline(registration);
    });
  });

  window.addEventListener("load", function () {
    navigator.serviceWorker.register(WORKER_URL)
      .then(function () { return navigator.serviceWorker.ready; })
      .then(function (registration) {
        saveLibraryFilesForOffline(registration);
        // Run once more a little later in case some library files loaded after "load".
        setTimeout(function () { saveLibraryFilesForOffline(registration); }, 5000);
      })
      .catch(function (error) {
        console.warn("PWA: could not start the service worker:", error);
      });
  });
})();
